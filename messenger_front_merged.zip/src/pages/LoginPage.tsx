import {LoginForm} from "@/components/form/LoginForm.tsx";

export function LoginPage(){
    return(
        <div className={"w-full flex items-center justify-center"}>

            <LoginForm/>
        </div>
    )
}

